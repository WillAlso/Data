#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SCHEDULER_DIALOG            102
#define IDD_SCHEDULEENTRYINFODLG        103
#define IDD_ENTRYINFO_DLG               103
#define IDR_HTML_SCHEDULER_DIALOG       104
#define IDR_HTML_SCHEDULEENTRYINFODLG   105
#define IDR_HTML_ENTRYINFO_DLG          105
#define IDD_DELETEENTRIEDLG             106
#define IDR_HTML_DELETEENTRIEDLG        107
#define IDD_DELETESCHEDULEDLG           108
#define IDR_HTML_DELETESCHEDULEDLG      109
#define IDD_MODIFYORDELETE              110
#define IDR_HTML_MODIFYORDELETE         111
#define IDR_MAINFRAME                   128
#define IDD_DELETESCHEDULEENTRYDLG      134
#define IDR_FILEMENU                    143
#define IDR_HELPMENU                    143
#define IDD_FILE_NEW                    144
#define IDD_FILE_OPEN                   145
#define IDD_FILE_EXIT                   146
#define IDR_HTML1                       149
#define IDD_HELP_ABOUTSCHEDULER         154
#define IDS_ENTERTITLE                  156
#define IDS_INVALIDTIME                 158
#define IDS_INVALIDDATE                 160
#define IDS_CANNOTOPENFILE              162
#define ID_32773                        32773
#define ID_32774                        32774
#define IDD_NEW_EVENT                   32775
#define IDD_EXIT                        32776
#define ID_32777                        32777
#define IDD_SAVE                        32778

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        166
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
