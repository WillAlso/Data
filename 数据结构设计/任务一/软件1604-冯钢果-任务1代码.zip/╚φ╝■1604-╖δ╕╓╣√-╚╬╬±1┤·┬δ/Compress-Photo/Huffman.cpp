#include "Huffman.h"
#include <iostream>
#include <stdlib.h>
using namespace std;
void Select(HTree pHT,int nSize,int &s1,int &s2)
{
	int i;
	int min;
	for(i = 1;i <= nSize;i++)
	{
		if(pHT[i].parent == 0)
		{
			min = i;
			break;
		}
	}
	for(i = 1;i <= nSize;i++)
	{
		if(pHT[i].parent == 0)
		{
			if(pHT[i].weight < pHT[min].weight)
			{
				min = i;
			}
		}
	}
	s1 = min;
	for(i = 1;i <= nSize;i++)
	{
		if(pHT[i].parent == 0 && i != s1)
		{
			min = i;
			break;
		}
	}
	for(i = 1;i <= nSize;i++)
	{
		if(pHT[i].parent == 0 && i != s1)
		{
			if(pHT[i].weight < pHT[min].weight)
			{
				min = i;
			}
		}
	}
	s2 = min;
}
int HuffmanCode(HCode &pHC,HTree &pHT)
{
	char cd[256] = {'0'};
	int cdlen = 0;
	pHC = (char**)malloc(512 * sizeof(char*));
	for(int i = 1;i < 512;i++)
	{
		pHT[i].weight = 0;
	}
	int p = 511;
	while(p != 0)
	{
		if(pHT[p].weight == 0)
		{
			pHT[p].weight = 1;
			if(pHT[p].lchild != 0)
			{
				p = pHT[p].lchild;
				cd[cdlen++] = '0';
			}else if(pHT[p].rchild == 0)
			{
				pHC[p] = (char*)malloc((cdlen + 1) * sizeof(char));
				cd[cdlen] = '\0';
				strcpy(pHC[p],cd);
			}
		}
		else if(pHT[p].weight == 1)
		{
			pHT[p].weight = 2;
			if(pHT[p].rchild != 0)
			{
				p = pHT[p].rchild;
				cd[cdlen++] = '1';
			}
		}else
		{
			pHT[p].weight = 0;
			p = pHT[p].parent;
			--cdlen;
		}
	}
	return 1;
}

int HuffmanTree(HTree &pHT,int *aWeight)
{
	int m = 2 * 256 - 1;
	pHT = (HTree)malloc((m + 1) * sizeof(HTNode));
	if(!pHT)
	{
		cout << "�ڴ�ʧ�ܣ�" << endl;
		cout << -1;
	}
	HTree p = pHT + 1;
	for(int i = 0;i < m;i++)
	{
		if(i < 256)
		{
			p->weight = aWeight[i];
			pHT[i].data = i - 1;
		}else
		{
			p->weight = 0;
			pHT[i].data = 255;
		}
		p->parent = 0;
		p->lchild = 0;
		p->rchild = 0;
		p++;
	}
	for(int i = 256 + 1;i <= m;i++)
	{
		int s1,s2;
		Select(pHT,i - 1,s1,s2);
		pHT[s1].parent = i;
		pHT[s2].parent = i;
		pHT[i].weight = pHT[s1].weight + pHT[s2].weight;
		pHT[i].lchild = s1;
		pHT[i].rchild = s2;
	}
	return 1;
}