//#include "Compress.h"
#include "Huffman.h"

struct HEAD{
	char aType[4];
	int nLength;
	int aWeight[256];
};

typedef char *BUFFER;

int Compress(const char *pFilename);
int InitHead(const char *pFilename,HEAD &sHead);
int Encode(const char *pFilename,const HCode pHC,char *pBuffer,const int nSize);
char Str2byte(const char *pBinStr);
int WriteFile(const char *pFilename,const HEAD sHead,const BUFFER pBuffer,const int nSize);
int Decompress(const char *compress_file);