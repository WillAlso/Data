#include "Compress.h"
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <bitset>
using namespace std;
#define ERROR -1
int Compress(const char *pFilename)
{
	HEAD sHead;
	if(ERROR == InitHead(pFilename,sHead))
	{
		return ERROR;
	}
	cout << sHead.nLength << " �ֽ�" << endl;

	HTree pHT = NULL;
	HuffmanTree(pHT,sHead.aWeight);
	if(!pHT)
	{
		return ERROR;
	}
	HCode pHC = NULL;
	HuffmanCode(pHC,pHT);
	free(pHT);
	if(!pHC)
	{
		return -1;
	}
	int nSize = 0;
	for(int i = 0;i < 256;i++)
	{
		nSize += sHead.aWeight[i] * strlen(pHC[i + 1]);
	}
	nSize = (nSize % 8) ? nSize / 8 + 1 : nSize / 8;
	BUFFER pBuffer = NULL;
	pBuffer = (char *) malloc(nSize * sizeof(char));
	Encode(pFilename,pHC,pBuffer,nSize);
	if(!pBuffer)
	{
		return ERROR;
	}
	int len = WriteFile(pFilename,sHead,pBuffer,nSize);
	free(pBuffer);
	if(len < 0)
	{
		return ERROR;
	}
	cout << len << " �ֽ�" << endl;
	cout << "ѹ������: " << (double)len / (double)sHead.nLength * 100 << "%" << endl;
	return 1;
}

int InitHead(const char *pFilename,HEAD &sHead)
{
	strcpy(sHead.aType,"HUF");
	sHead.nLength = 0;
	for(int i = 0;i < 256;i++)
	{
		sHead.aWeight[i] = 0;
	}
	FILE *in = fopen(pFilename,"rb");
	if(!in)
	{
		cout << "���ļ�ʧ�ܣ�" << endl;
		return -1;
	}
	int ch;
	while((ch = fgetc(in)) != EOF)
	{
		sHead.aWeight[ch]++;
		sHead.nLength++;
	}
	fclose(in);
	in = NULL;
	return 1;
}

int Encode(const char *pFilename,const HCode pHC,char *pBuffer,const int nSize)
{
	FILE *in = fopen(pFilename,"rb");
	if(!in)
	{
		cout << "���ļ�ʧ�ܣ�" << endl;
		return -1;
	}
	char cd[256] = {0};
	int pos = 0;
	int ch;
	while((ch = fgetc(in)) != EOF)
	{
		strcat(cd,pHC[ch + 1]);
		while(strlen(cd) >= 8)
		{
			pBuffer[pos++] = Str2byte(cd);
			for(int i = 0;i < 256 - 8;i++)
			{
				cd[i] = cd[i + 8];
			}
		}
	}
	if(strlen(cd) > 0)
	{
		pBuffer[pos++] = Str2byte(cd);
	}
	return 1;
}

char Str2byte(const char *pBinStr)
{
	char b = 0x00;
	for(int i = 0;i < 8;i++)
	{
		b = b << 1;
		if(pBinStr[i] == '1')
		{
			b = b | 0x01;
		}
	}
	return b;
}

int WriteFile(const char *pFilename,const HEAD sHead,const BUFFER pBuffer,const int nSize)
{
	char filename[256] = {0};
	strcpy(filename,pFilename);
	strcat(filename,".huf");
	FILE  *out = fopen(filename,"wb");
	if(!out)
	{
		cout << "����ļ�ʧ�ܣ�" << endl;
	}
	fwrite(&sHead,sizeof(HEAD),1,out);
	fwrite(pBuffer,sizeof(char),nSize,out);
	fclose(out);
	out = NULL;
	cout << "�����ļ�:" << filename << endl;
	int len = sizeof(HEAD) + strlen(pFilename) + 1 +nSize;
	return len;
}

int Decompress(const char *compress_file)
{
	char decompress_file[256];
	strncpy(decompress_file, compress_file, strlen(compress_file) - 4);
	decompress_file[strlen(compress_file) - 4] = '\0';
	ifstream read;
	read.open(compress_file, ios::binary);
	if (read.fail())
	{
		cout << "��ȡ�ļ�ʧ��" << endl;
		return 0;
	}
	ofstream write;
	write.open(decompress_file);
	if (write.fail())
	{
		cout << "д���ļ�ʧ��" << endl;
		return 0;
	}
	HEAD sHead;
	read.seekg(0, ios::end);
	read.seekg(0, ios::beg);
	read.read((char*)(&sHead), sizeof(sHead));
	HTNode *pHT = (HTNode*)malloc((512) * sizeof(HTNode));
	HuffmanTree(pHT, sHead.aWeight);
	read.seekg(sizeof(HEAD), ios::beg);
	char next;
	int pos = 511;
	read.get(next);
	unsigned long long count_size = 0;
	while (1)
	{
		bitset<8>b(next);
		read.get(next);
		for (int i = b.size() - 1; i >= 0; i--)
		{
			if (b.test(i))
				pos = pHT[pos].rchild;
			else
				pos = pHT[pos].lchild;
			if (pHT[pos].lchild == 0 && pHT[pos].rchild == 0)
			{
				write << pHT[pos].data;
				pos = 511;
				++count_size;
			}
			if (count_size + 12 >= sHead.nLength)
				break;
		}
		if (count_size + 12 >= sHead.nLength)
			break;
	}
	cout << "��ѹ���" << endl;
	read.close();
	write.close();
	return 1;
}