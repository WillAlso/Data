#include <iostream>
#include <stdlib.h>
#include "Compress.h"
using namespace std;
int main()
{
	int choice = -1;
	while(choice != 0)
	{
		cout << "**********Huffman�ļ�ѹ��***********" << endl;
		cout << "1.ѹ��ͼ��" << endl;
		cout << "2.��ѹͼ��" << endl;
		cout << "0.�˳�" << endl;
		cin >> choice;
		char filename[256];
		switch(choice)
		{
		case 1:
			{
				system("cls");
				cout << "�������ļ�λ��:";
				cin >> filename;
				Compress(filename);
				break;
			}
		case 2:
			{
				system("cls");
				cout << "�������ļ�λ��:";
				cin >> filename;
				Decompress(filename);
				break;
			}
		case 0:
			{
				system("exit");
			}
		default:
			break;
		}
	}
	
	

	return 0;
}