struct HTNode
{
	int weight;
	int parent;
	int lchild;
	int rchild;
	char data;
};
typedef HTNode *HTree;
typedef char **HCode;
int HuffmanTree(HTree &pHT,int *aWeight);
int HuffmanCode(HCode &pHC,HTree &pHT);
void Select(HTree pHT,int nSize,int &s1,int &s2);