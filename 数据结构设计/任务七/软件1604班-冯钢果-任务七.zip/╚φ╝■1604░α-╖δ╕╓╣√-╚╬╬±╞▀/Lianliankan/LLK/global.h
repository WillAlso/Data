#pragma once

typedef struct tagVertex{
	int row;
	int col;
	int info;
}Vertex;

#define BLANK -1